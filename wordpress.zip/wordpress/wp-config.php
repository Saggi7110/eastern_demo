<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'eastern_task' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '@#WqTjq#w>A*VS$*n7fT-$yZcxny:>lu.]kjqE:m2Jd;U/Lax.hQ:UIsU.,:>cj9' );
define( 'SECURE_AUTH_KEY',  '%wwB8gJ 3fwreu*;  a*2s9t K-bsvTn]1/;ATJ2pXa+h/]>=doTRYe3smf1_P3w' );
define( 'LOGGED_IN_KEY',    ' h.axiF`fxiMx<$r:kjuO#OxC3TmcYmh|E^l21vFteGe]y6i&|9d4Y32f$/l9|7d' );
define( 'NONCE_KEY',        'U7Aq8%YnX /EPzYQG9eQG&R{Q`Y`1,aDPe<BT`<P4$v,IAv+>cbU]Bg|PCaJTI,w' );
define( 'AUTH_SALT',        'UBZWuIQ^zbD/,!}A8Y.~4<,;t*z_eg7>{l/+ v)L+`JX!@lU@J;ni:7ED+EKh%+e' );
define( 'SECURE_AUTH_SALT', '088xmTrBOQ%9f#~I/wF1gkgG3|)M6aJ/0Oc*uul_MaP5,7*E-9dc;Gu+7?S?}lOr' );
define( 'LOGGED_IN_SALT',   'So5hLwu7mszt8`6&+HeL%}A>>V{qA0#].dlnp7BI|-IyRym8M}AIDLCD@b[[-_Qu' );
define( 'NONCE_SALT',       'V`Rye:|5+sT46]nL}Buv&4`R+ -6/c<2<<GJBk2Fv02@OI!nZZmi*6!$Lv1Av!d{' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
